# Portofolio — Aldi

Ini adalah situs portofolio statis (HTML/CSS/JS murni). Anda bisa membukanya langsung dengan klik `index.html` atau meng-host di GitHub Pages / Netlify.

## Cara pakai cepat (tanpa hosting)
1. Ekstrak ZIP ini.
2. Buka file `index.html` dengan browser (Chrome/Edge/Safari). Selesai.

## Edit konten
- Ubah data proyek/skill/pengalaman di `data.json`.
- Ganti teks di `index.html` (bagian Tentang, judul, CTA).
- Ganti avatar: taruh `avatar.jpg` di folder `assets` (ukuran bujur sangkar).
- Tambahkan `assets/CV-Aldi.pdf` jika ingin tombol CV berfungsi.

## Hosting gratis (opsional)
### GitHub Pages
1. Buat repo publik baru di GitHub (mis: `portfolio`).
2. Upload semua file.
3. Masuk ke *Settings → Pages* → `Deploy from a branch`, pilih `main` dan `/root` lalu `Save`.
4. Tunggu beberapa menit, situs Anda akan tampil di URL GitHub Pages.

### Netlify (drag & drop)
1. Masuk ke netlify.com, login.
2. *Add new site* → *Deploy manually* → drag & drop folder ini.
3. Dapatkan URL unik, bisa pakai domain custom bila perlu.

Selamat berkarya!